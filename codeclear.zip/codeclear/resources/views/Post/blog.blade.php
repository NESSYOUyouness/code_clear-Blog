@extends('Layout.app')
@section('content')

    {{-- <link href="{{asset('assets2/css/bootstrap.css ') }} " rel="stylesheet"> --}}
    <link href="{{asset('assets2/style.css') }} " rel="stylesheet">
    <link href="{{asset('assets2/css/animate.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/responsive.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/colors.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/version/marketing.css ') }}" rel="stylesheet">
    <link
      rel="stylesheet"
      href="https://unicons.iconscout.com/release/v4.0.0/css/line.css"
    />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <div id="wrapper">
    <section class="section lb">
        <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">

                <div class="page-wrapper">
                        <div class="blog-list-widget-blog ">
                            <div class="list-group">
                                @foreach ($posts_blog as $itemTwo )
                                    <div class="w-100 justify-content-between">
                                        <img src="/{{$itemTwo->avatar}}" alt="" class="img-fluid float-left">
                                        <a href="{{route('Post',['id'=>$itemTwo->id])}}">
                                            <h5 class="mb-1-blog">{{$itemTwo->post_title}}</h5>
                                            <small>
                                            <i class="fa fa-clock-o"></i>
                                                    {{ \Carbon\Carbon::parse($itemTwo->created_at)->format('d:m:Y')}}
                                            </small>
                                            <p class="mb-2-blog"> {{ substr($itemTwo->post_about, 0, 90)}}.. </p>
                                        </a>
                                    </div>
                                    <hr class="br-blog">
                                @endforeach
                                <div class="d-flex justify-content-center " style="margin:5%  ; color: white;">
                                    {!! $posts_blog->links('pagination::bootstrap-4') !!}
                                </div>
                                <style>
                                    .pagination .page-item .page-link{
                                        color: white;
                                    }

                                    .br-blog{
                                        margin: 10px 10px 30px 10px;
                                    }

                                    .mb-2-blog{
                                        font-weight: 200;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 14px;
                                    }
                                    .mb-1-blog{
                                        margin-top: 8px;
                                        font-weight: 900;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 21px;
                                    }
                                    .blog-list-widget-blog img {
                                        margin-right: 15px;
                                        margin-bottom: 18px;
                                        max-width: 250px;
                                        max-height: 390px;
                                        border-radius: 10px;
                                        padding: 4px;
                                        border: none;
                                    }
                                </style>
                            </div>
                        </div>
                 </div>
                <hr class="invis">

            </div><!-- end col -->
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="sidebar">
                    <div class="widget">
                        <h2 class="widget-title">Recent Posts</h2>
                        <div class="blog-list-widget">
                            <div class="list-group">
                                @foreach ($postsTwo as $itemTwo )
                                    <a href="marketing-single.html" class="list-group-item list-group-item-action flex-column align-items-start">
                                        <div class="w-100 justify-content-between">
                                            <a href="{{route('Post',['id'=>$itemTwo->id])}}">
                                                <img src="/{{$itemTwo->avatar}}" alt="" class="img-fluid float-left">
                                                <h5 class="mb-1">{{$itemTwo->post_title}}</h5>

                                            <small>
                                                <a href="#"><i class="fa fa-clock-o"></i>
                                                    {{ \Carbon\Carbon::parse($itemTwo->created_at)->format('d:m:Y')}}
                                                </a>
                                            </small>
                                        </a>
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <style>
                        .mb-1{
                            margin-top: -20px
                        }
                    </style>

                    <div  class="widget">
                                    <h2 class="widget-title">The Last Project</h2>
                                    <div class="banner-spot clearfix">
                                        <div class="banner-img">
                                            @foreach ($last_project as $last )
                                                <div class="banner-img">
                                                    <img src="/{{$last->avatar}}" class="img-last">
                                                </div>
                                            @endforeach
                                            <style>
                                                .img-last{
                                                    max-width: 300px;
                                                    border-radius: 8px;
                                                    height: 200px;
                                                }
                                            </style>
                                        </div>
                                    </div><!-- end banner -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Popular Categories</h2>
                        <div class="link-widget">
                            <ul>
                                @foreach($categorys  as $Category)
                                    <li>
                                        {{$Category->Category_Name }}
                                        <span class="badge badge-secondary">{{$Category->posts->count() }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        </div><!-- end link-widget -->
                    </div>
                    <div class="widget" id="contact">
                        <h2 class="widget-title"> Contact us </h2>
                        <form  >
                            <span id="showMessage"></span>
                            <div class="form-group">
                              <input type="text" class="form-control"   placeholder="Name" id="name" />
                            </div>

                            <div class="form-group input-field ">
                              <input type="email" class="form-control "   placeholder="Email" id="email" spellcheck="false"  />
                              <i class="uil uil-envelope email-icon" id="emaill-icon"></i>
                            </div>

                            <div class="form-group">
                              <textarea class="form-control" placeholder="Message" id="message" rows="3"></textarea>
                            </div>

                            <button id="contact-send" style="text-align: center; background-color: #4e78a3 !important;    width: 100%;"
                             class="btn send-us"  >Send
                            </button>
                        </form >
                    </div>
                    <script>


                            var input  = document.getElementById("email");
                            var emailIcon  = document.getElementById("emaill-icon");

                            input.addEventListener("keyup", () =>{
                            let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

                            if(input.value === ""){
                                emailIcon.classList.replace("uil-check-circle", "uil-envelope");
                                return emailIcon.style.color = "#b4b4b4";
                            }
                            if(input.value.match(pattern)){
                                emailIcon.classList.replace("uil-envelope", "uil-check-circle");
                                return emailIcon.style.color = "#4bb543"
                            }
                            emailIcon.classList.replace("uil-check-circle", "uil-envelope");
                            emailIcon.style.color = "#de0611"
                            })

                        //Validation input email //

                        function validate() {
                            let email = document.querySelector("#email");
                            let message = document.querySelector("#message");
                            let name = document.querySelector("#name");
                            let sendBtn = document.querySelector(".send-us");

                            sendBtn.addEventListener("click" ,(e)=>{
                                e.preventDefault();
                                var email_validation = email.value;
                                const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                                var is_valid = pattern.test(String(email_validation).toLowerCase());

                                if(is_valid){
                                    sendMail( email.value , message.value , name.value) ;
                                    success();
                                    showMessage.innerHTML = ""
                                }
                                else{
                                    if( email.value == "" && message.value == "" &&  name.value == "")
                                        emptyerror();

                                }

                            });


                        }
                        validate();

                        function sendMail( email , message ,name) {
                            emailjs.send("service_up8o4oc", "template_c2paa2h",{
                                to_name: email,
                                from_name: name ,
                                message: message,
                            });



                        }
                        function emptyerror() {
                            swal({
                                title: "Oh No .....",
                                text: "Fields cannot be empty!",
                                icon: "error",
                            });
                        }
                        function success() {
                            swal({
                                title: "Email sent successfully",
                                text: "We try to reply in 24 hours",
                                icon: "success",
                            });
                            email.value = '';
                            message.value = '';
                            name.value = '';
                        }

                    </script>

                </div><!-- end sidebar -->
            </div><!-- end col -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
  </div><!-- end wrapper -->

  <script type="text/javascript"src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

    <script type="text/javascript">
    emailjs.init('ZzGiktdCe9W_zrWmU')
    </script>

    <script src="https://cdn.staticfile.org/jquery/2.1.1-rc2/jquery.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script src="{{ asset('codeeditor/index.js') }}"></script>
    <script src="{{ asset('codeeditor/main.js ') }}"></script>


@endsection

<style>

.input-field {
  position: relative;
}
.input-field input {
  font-size: 15px;
  font-weight: 400;
  color: #333;
}
input::placeholder {
  color: #b4b4b4;
}
.input-field .email-icon {
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 22px;
  color: #b4b4b4;
}
</style>























