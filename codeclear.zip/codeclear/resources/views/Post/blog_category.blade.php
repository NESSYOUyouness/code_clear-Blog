@extends('Layout.app')
@section('content')

    <link href="{{asset('assets2/css/bootstrap.css ') }} " rel="stylesheet">
    <link href="{{asset('assets2/style.css') }} " rel="stylesheet">
    <link href="{{asset('assets2/css/animate.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/responsive.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/colors.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/version/marketing.css ') }}" rel="stylesheet">

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">

    <link rel="stylesheet" href="{{ asset('codeeditor/index.css') }}">


  <div id="wrapper">
    <section class="section lb">
        <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">

                <div class="page-wrapper">
                        <div class="blog-list-widget-blog ">
                            <div class="list-group">
                                @foreach ($posts_blog as $itemTwo )
                                    <div class="w-100 justify-content-between">
                                        <img src="/{{$itemTwo->avatar}}" class="img-fluid float-left">
                                        <a href="{{route('Post',['id'=>$itemTwo->post_id])}}">
                                            <h5 class="mb-1-blog">{{$itemTwo->post_title}}</h5>
                                            <small>
                                            <i class="fa fa-clock-o"></i>
                                                {{ \Carbon\Carbon::parse($itemTwo->created_at)->format('d:m:Y')}}
                                            </small>
                                            <p class="mb-2-blog"> {{ substr($itemTwo->post_about, 0, 90)}}.. </p>
                                        </a>
                                    </div>
                                    <hr class="br-blog">
                                @endforeach
                                <div class="d-flex justify-content-center " style="margin:5%  ; color: white;">
                                    {!! $posts_blog->links('pagination::bootstrap-4') !!}
                                </div>
                                <style>
                                    .pagination .page-item .page-link{
                                        color: white;
                                    }

                                    .br-blog{
                                        margin: 10px 10px 30px 10px;
                                    }

                                    .mb-2-blog{
                                        font-weight: 200;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 14px;
                                    }
                                    .mb-1-blog{
                                        margin-top: 8px;
                                        font-weight: 900;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 21px;
                                    }
                                    .blog-list-widget-blog img {
                                        margin-right: 15px;
                                        margin-bottom: 18px;
                                        max-width: 250px;
                                        max-height: 390px;
                                        border-radius: 10px;
                                        padding: 4px;
                                        border: none;
                                        width: 250px;
                                        height: 150px;
                                    }
                                </style>
                            </div>
                        </div>
                 </div>
                <hr class="invis">

            </div><!-- end col -->
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="sidebar">
                    <div class="widget">
                        <h2 class="widget-title">Recent Posts</h2>
                        <div class="blog-list-widget">
                            <div class="list-group">
                                @foreach ($postsTwo as $item )
                                    <a href="{{route('Post',['id'=>$item->id])}}" class="list-group-item list-group-item-action flex-column align-items-start">
                                        <div class="w-100 justify-content-between">
                                            <a href="{{route('Post',['id'=>$item->id])}}">
                                                <img src="/{{$item->avatar }}" alt="" class="img-fluid float-left">
                                                <h5 class="mb-1">{{$item->post_title}}</h5>

                                            <small>
                                                <a href="#"><i class="fa fa-clock-o"></i>
                                                    {{ \Carbon\Carbon::parse($item->created_at)->format('d:m:Y')}}
                                                </a>
                                            </small>
                                        </a>
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <style>
                        .mb-1{
                            margin-top: -20px
                        }
                    </style>

                    <div id="" class="widget">
                                    <h2 class="widget-title">The Last Project</h2>
                                    <div class="banner-spot clearfix">
                                        <div class="banner-img">
                                            @foreach ($last_project as $last )
                                                <div class="banner-img">
                                                    <img src="/{{$last->avatar}}" class="img-last">
                                                </div>
                                            @endforeach
                                            <style>
                                                .img-last{
                                                    max-width: 300px;
                                                    border-radius: 8px;
                                                    height: 200px;
                                                }
                                            </style>
                                        </div>
                                    </div><!-- end banner -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Most Popular </h2>

                        <div class="instagram-wrapper clearfix">
                            @foreach ($lost_popular as $last )
                                <a href="#">
                                    <img src="/{{$last->avatar}}" class="img-fluid-most">
                                </a>
                            @endforeach
                            <style>
                                .img-fluid-most{
                                max-width: 90px;
                                max-height: 90px;
                                height: 90px;
                                border-radius: 8px;
                            }
                            </style>
                        </div><!-- end Instagram wrapper -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Popular Categories</h2>
                        <div class="link-widget">
                            <ul>
                                @forelse ($categorys  as $Category)
                                    <li>
                                        {{$Category->Category_Name }}
                                        <span class="badge badge-secondary">{{$Category->posts->count() }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        </div><!-- end link-widget -->
                    </div><!-- end widget -->
                </div><!-- end sidebar -->
            </div><!-- end col -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
  </div><!-- end wrapper -->

  {{-- @endforeach --}}
    <script src="{{asset('assets2/js/animate.js') }}"></script>

    <script src="https://cdn.staticfile.org/jquery/2.1.1-rc2/jquery.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script src="{{ asset('codeeditor/index.js') }}"></script>
    <script src="{{ asset('codeeditor/main.js ') }}"></script>


@endsection

























