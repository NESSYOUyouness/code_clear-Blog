@extends('Layout.app')
@section('content')



<br><br>
<table class="table table-dark table-striped container">

  <tr >

    <th scope="row"><span></span></th>
    <th scope="row"><span>id</span></th>
    <th scope="row"><span></span></th>
    <th scope="row"><span> Post Link</span></th>
    <th scope="row"><span></span></th>
    <th scope="row"><span>Post Name</span></th>
    <th scope="row"><span> Category id</span></th>
    <th scope="3"> </th>
    <th scope="3">Actions </th>
    <th scope="3"> </th>

  </tr >
    @if ($posts->count()>0 )
        @foreach ($posts as $item)
            <tr class="container">
                <td ></td>
                <td >{{$item->id}}</td>
                <td ></td>
                <td >{{$item->post_name}}</td>
                <td ></td>
                <td >{{$item->post_link}} </td>
                <td >{{$item->category_id}}</td>
                <td >
                    <a  class="btn btn-danger" href="{{route('posts.delete',['id'=>$item->id])}}">
                        <i class="fa fa-trash" ></i>
                    </a>
                </td>
                <td >
                    <a  class="btn btn-warning" href="{{route('posts.edit',['id'=>$item->id])}}">
                        <i class="fa fa-edit"></i>
                    </a>
                </td>
                <td >
                    <a  class="btn btn-info" href="{{route('post.create')}}"><i class="fa fa-user-plus"></i></a>
                </td>
            </tr>
        @endforeach
    @else
        <br><br><br><br><br><br><br>
        <a class="btn btn-info btn-add" href="{{route('post.create')}}"> Add category<i class="uil uil-user-plus"></i></a>
    @endif

</table>
{!! $posts->links('pagination::bootstrap-4') !!}
<br><br><br><br>
@endsection

