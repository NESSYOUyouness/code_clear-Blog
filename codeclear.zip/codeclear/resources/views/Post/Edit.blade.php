@extends('Layout.app')
@section('content')
<div class="container p-5">
    <div class="row justify-content-center ">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('posts.update',['id'=>$post->id]) }}" enctype="multipart/form-data">
                        @csrf

                        <div class="row mb-3">
                            <label   class="col-md-4 col-form-label text-md-end">{{ __('Category ') }}</label>
                            <div class="col-md-6">

                                <select class="form-select " name="category_id_vw">
                                    @foreach($category as $item )
                                        <option value="{{$item->id}}">{{$item->Category_Name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label   class="col-md-4 col-form-label text-md-end">{{ __('Admin ') }}</label>
                            <div class="col-md-6">

                                <select class="form-select " name="user_id_vw">
                                    @foreach($users as $item )
                                        <option value="{{$item->id}}">{{$item->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Name </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" value="{{$post->post_name}}" name="name_post_vw">
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Title </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" value="{{$post->post_title}}" name="post_title_view">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Image </label>
                            <div class="col-md-6">
                                <input  type="file" class="form-control"  value="{{$post->avatar}}" name="post_image_view">
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Description </label>
                            <div class="col-md-6">
                                <textarea name="post_dsrpt"  class="form-control" cols="30" rows="10"> {{$post->post_about}}</textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Link Youtube</label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" value="{{$post->post_link}}" name="link_youtube">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Download File</label>
                            <div class="col-md-6">
                                <input  type="file" class="form-control" value="{{$post->download_file}}" name="download_file_vw">
                            </div>
                        </div>



                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                                <a href="{{route('category.create')}}" type="submit" class="btn btn-primary">
                                    {{ __('Add Category') }}
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br>

@endsection
