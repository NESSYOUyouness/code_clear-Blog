@extends('Layout.app')
@section('content')

    <link href="{{asset('assets2/css/bootstrap.css ') }} " rel="stylesheet">
    <link href="{{asset('assets2/style.css') }} " rel="stylesheet">
    <link href="{{asset('assets2/css/animate.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/responsive.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/colors.css ') }}" rel="stylesheet">
    <link href="{{asset('assets2/css/version/marketing.css ') }}" rel="stylesheet">

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">

    <link rel="stylesheet" href="{{ asset('codeeditor/index.css') }}">
{{-- @foreach ($posts as $post) --}}

<div id="wrapper">
    <section class="section lb">
        <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                <div class="page-wrapper">
                <div class="blog-custom-build">

                    <div class="blog-box wow fadeIn">

                        <a href="{{route('Post',[$post->id] )}}"><span class="path-cl">{{  request()->route()->getName() }}  </span></a>
                        <svg xmlns="http://www.w3.org/2000/svg"  margin-bottom= "-3px" style=" margin-bottom: -3px;"  width="16" height="16" fill="currentColor" class="bi bi-caret-right  " viewBox="0 0 16 16">
                            <path d="M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z"/>
                        </svg>
                        @foreach ($categorys as $category )
                          @if ($category->id == $post->category_id )
                            <span style="color: #aaaaaa;transition: color .25s;" class="path-name"> {{$category->Category_Name}}</span><br>
                          @endif
                        @endforeach

                        <h1 class="post-nam">
                            {{$post->post_name}}
                        </h1>
                        @foreach ( $languages as $item )
                        @if ($item->post_id == $post->id)
                            <span class="tag-top">{{$item->language_Name}}</span>
                            @endif
                        @endforeach
                        <hr>
                        <div class="post-media">
                            <a  title="">
                                <img src="/{{$post->avatar}}" alt="" class="img-fluid img-fluid-blog">
                                <div class="hovereffect">
                                    <span></span>
                                </div>
                                <style>
                                    .img-fluid-blog{
                                        height: 100%;
                                    }
                                </style>
                                <!-- end hover -->
                            </a>
                        </div>
                        <!-- end media -->
                        <div class="blog-meta big-meta text-center">
                            <div class="post-sharing">
                                <ul class="list-inline">
                                    <li><a href="#" class="fb-button btn btn-primary"><i class="fa fa-facebook"></i> <span class="down-mobile">Share on Facebook</span></a></li>
                                    <li><a href="#" class="tw-button btn btn-primary"><i class="fa fa-twitter"></i> <span class="down-mobile">Tweet on Twitter</span></a></li>
                                    <li><a href="#" class="gp-button btn btn-primary"><i class="fa fa-google-plus"></i></a></li>
                                </ul>

                            </div><!-- end post-sharing -->
                            <br>
                            <h4>
                                  <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" style=" margin-bottom: -4px;" fill="currentColor" class="bi bi-award-fill code-title" viewBox="0 0 16 16">
                                    <path d="m8 0 1.669.864 1.858.282.842 1.68 1.337 1.32L13.4 6l.306 1.854-1.337 1.32-.842 1.68-1.858.282L8 12l-1.669-.864-1.858-.282-.842-1.68-1.337-1.32L2.6 6l-.306-1.854 1.337-1.32.842-1.68L6.331.864 8 0z"/>
                                    <path d="M4 11.794V16l4-1 4 1v-4.206l-2.018.306L8 13.126 6.018 12.1 4 11.794z"/>
                                  </svg>&nbsp;
                                {{$post->post_title}}
                            </h4>
                            <p >
                                {{-- {{date('Y-m-d\Th:m:s',  strtotime(old('start_date')))}} --}}
                                {!!$post->post_about !!}
                            </p>
                            <br><br>
                            <small><a href="#"><i class="fa fa-clock-o"></i> {{ \Carbon\Carbon::parse($post->created_at)->format('d:m:Y')}}</a></small>
                            <small><a href="#"><i class="fa fa-eye"></i> 2291</a></small>
                            @foreach ( $languages as $item )
                                @if ($item->post_id == $post->id)
                                    <span class="tag-main"> {{$item->language_Name}}</span>
                                @endif
                            @endforeach
                        </div>
                        <hr class="invis">

                    </div>

                    <div class="blog-box wow fadeIn">
                        <span class="tag-top">See more details on </span>
                        <img class="youtube-logo" src="https://supersimple.dev/public/img/exercises/youtube/icons/youtube-logo.svg" />
                        <br><br>
                        <div class="post-media">
                            <iframe  src="https://www.youtube.com/embed/{{$post->post_link}}"
                                width="650px" height="370px" title="YouTube video player"
                                frameborder="0" allow="accelerometer; autoplay; clipboard-write;
                                encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>
                            </iframe>
                        </div>
                    </div><hr>
                    <br><br>
                    <span class="tag-top" >All Details About The Project</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="29" fill="currentColor" class="bi bi-qr-code-scan code-title border-icon" viewBox="0 0 16 16">
                        <path d="M0 .5A.5.5 0 0 1 .5 0h3a.5.5 0 0 1 0 1H1v2.5a.5.5 0 0 1-1 0v-3Zm12 0a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-1 0V1h-2.5a.5.5 0 0 1-.5-.5ZM.5 12a.5.5 0 0 1 .5.5V15h2.5a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5v-3a.5.5 0 0 1 .5-.5Zm15 0a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1 0-1H15v-2.5a.5.5 0 0 1 .5-.5ZM4 4h1v1H4V4Z"/>
                        <path d="M7 2H2v5h5V2ZM3 3h3v3H3V3Zm2 8H4v1h1v-1Z"/>
                        <path d="M7 9H2v5h5V9Zm-4 1h3v3H3v-3Zm8-6h1v1h-1V4Z"/>
                        <path d="M9 2h5v5H9V2Zm1 1v3h3V3h-3ZM8 8v2h1v1H8v1h2v-2h1v2h1v-1h2v-1h-3V8H8Zm2 2H9V9h1v1Zm4 2h-1v1h-2v1h3v-2Zm-4 2v-1H8v1h2Z"/>
                        <path d="M12 9h2V8h-2v1Z"/>
                      </svg>
                    <div class="container-paraghraph">

                        <ul class="ul">
                            @foreach ( $languages as $item )
                                @if ($item->post_id == $post->id)
                                    <li>
                                        <div><span></span>
                                        <div class="title-paraghraph">{{$item->language_Name}}</div>
                                        <div class="info-paraghraph">{{$item->language_about}}</div>
                                        </div> <span class="number-paraghraph"><span>Begin</span> <span>End</span></span>
                                    </li>
                                @endif
                            @endforeach
                        </ul>
                    </div>

                    <br><br> <hr>
                    <span class="tag-top">
                        These Files Contain
                        @foreach ( $languages as $item )
                            @if ($item->post_id == $post->id)
                                {{$item->language_Name }}
                            @endif
                        @endforeach
                        Code You Can Copy And Paste into Your Project
                    </span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="29" style="margin-bottom: -10px; margin-left: -5px;" fill="currentColor" class="bi bi-code code-title border-icon" viewBox="0 0 16 16">
                        <path d="M5.854 4.854a.5.5 0 1 0-.708-.708l-3.5 3.5a.5.5 0 0 0 0 .708l3.5 3.5a.5.5 0 0 0 .708-.708L2.707 8l3.147-3.146zm4.292 0a.5.5 0 0 1 .708-.708l3.5 3.5a.5.5 0 0 1 0 .708l-3.5 3.5a.5.5 0 0 1-.708-.708L13.293 8l-3.147-3.146z"/>
                    </svg><br><br><br>


                    <div class="blog-box wow fadeIn">
                        <section class="code-editor" codepen="AsFJh" user="skyinlayer">
                            <div class='embed-nav'>
                                <i class="iconfont icon toggle">&#xe60a;</i>
                                <ul></ul>

                            </div>
                            <div class="panel" >
                              <div id="code">
                                @foreach ( $languages as $item )
                                @if ($item->post_id == $post->id)
                                    <section type="{{$item->language_Name }}">

                                    <pre  >
                                        <code  class='language-css' >
  {!!$item->language_code !!}
                                        </code>
                                    </pre>
                                    </section>
                                @endif
                                @endforeach

                              </div>
                              <button id="copy-button">Copy</button>
                            </div>
                          </section>
                    </div><!-- end blog-box -->
                    <hr><br>
                    <span class="tag-top">Conclusion and Final Words</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="27" height="29" style="margin-bottom: -10px; margin-left: -8px;" fill="currentColor" class="bi bi-hourglass-split code-title code-title border-icon" viewBox="0 0 16 16">
                        <path d="M2.5 15a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11zm2-13v1c0 .537.12 1.045.337 1.5h6.326c.216-.455.337-.963.337-1.5V2h-7zm3 6.35c0 .701-.478 1.236-1.011 1.492A3.5 3.5 0 0 0 4.5 13s.866-1.299 3-1.48V8.35zm1 0v3.17c2.134.181 3 1.48 3 1.48a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351z"/>
                    </svg><br><br>
                    <div class="container-paraghraph-down">
                        <ul class="ul">
                            <li>
                                <div class="title-paraghraph">
                                    If you encounter any problems or your code does not work as expected,
                                    you can download the source code files by clicking on the given download button. it's free
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="download-container">
                        <a class="download-btn"> <i class="fa fa-download"></i> Download Code Files</a>
                        <div class="countdown"></div>
                        <div class="pleaseWait-text">Please Wait...</div>
                        <div class="manualDownload-text">Direct Link
                            <a href="{{asset($post->download_file)}}"
                                class="manualDownload-link">click here.
                            </a>
                        </div>
                    </div>

                    <div class="container-paraghraph-down">
                            @include('include.comment')
                    </div>
                </div>
                </div>
                <hr class="invis">

            </div><!-- end col -->
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="sidebar">
                    <div class="widget">
                        <h2 class="widget-title">Recent Posts</h2>
                        <div class="blog-list-widget">
                            <div class="list-group">
                                @foreach ($postsTwo as $itemTwo )
                                    <a href="{{route('Post',['id'=>$itemTwo->id])}}"class="list-group-item list-group-item-action flex-column align-items-start">
                                        <div class="w-100 justify-content-between">
                                            <img src="/{{$itemTwo->avatar}}" alt="" class="img-fluid float-left">
                                            <h5 class="mb-1">{{$itemTwo->post_title}}</h5>
                                            <small><a href="#"><i class="fa fa-clock-o"></i> {{ \Carbon\Carbon::parse($post->created_at)->format('d:m:Y')}}</a></small>
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <style>
                        .mb-1{
                            margin-top: -20px
                        }
                    </style>

                    <div id="" class="widget">
                                    <h2 class="widget-title">The Last Project</h2>
                                    <div class="banner-spot clearfix">
                                        @foreach ($last_project as $last )
                                            <div class="banner-img">
                                                <img src="/{{$last->avatar}}" class="img-last">
                                            </div>
                                        @endforeach
                                        <style>
                                            .img-last{
                                                max-width: 300px;
                                                border-radius: 8px;
                                                height: 200px;
                                            }
                                        </style>
                                    </div>
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Most Popular </h2>

                        <div class="instagram-wrapper clearfix">
                            @foreach ($lost_popular as $last )
                                <a href="#">
                                    <img src="/{{$last->avatar}}" class="img-fluid-most">
                                </a>
                            @endforeach
                            <style>
                                .img-fluid-most{
                                max-width: 90px;
                                max-height: 90px;
                                height: 90px;
                                border-radius: 8px;
                            }
                            </style>

                        </div><!-- end Instagram wrapper -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Popular Categories</h2>
                        <div class="link-widget">
                            <ul>
                                @forelse ($categorys  as $Category)
                                    <li>
                                        {{$Category->Category_Name }}
                                        <span class="badge badge-secondary">{{$Category->posts->count() }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        </div><!-- end link-widget -->
                    </div>
                    <!-- end widget -->
                </div><!-- end sidebar -->
            </div><!-- end col -->
        </div><!-- end row -->
    </div><!-- end container -->
    </section>
</div><!-- end wrapper -->

  {{-- @endforeach --}}
    <script src="{{asset('assets2/js/animate.js') }}"></script>

    <script src="https://cdn.staticfile.org/jquery/2.1.1-rc2/jquery.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script src="{{ asset('codeeditor/index.js') }}"></script>
    <script src="{{ asset('codeeditor/main.js ') }}"></script>

<script>
    document.addEventListener('DOMContentLoaded', () => {
          // hljs.initHighlightingOnLoad();

    const codeBlock = document.getElementById('code');
    const copyButton = document.getElementById('copy-button');
    const copySuccess = document.getElementById('copy-success');

    const copyTextHandler = () => {
    const text = codeBlock.innerText;
        navigator.clipboard.writeText(text).then(() => {
            copyButton.innerHTML = "Copied!";
            setTimeout(() => {
                copyButton.innerHTML = "Copy";
            }, 1000);

            },
            () => {
                console.log('Error writing to the clipboard');
                }
        );
    };

    copyButton.addEventListener('click', copyTextHandler );
</script>

<script type="text/javascript">
  const downloadBtn = document.querySelector(".download-btn");
  const countdown = document.querySelector(".countdown");
  const pleaseWaitText = document.querySelector(".pleaseWait-text");
  const manualDownloadText = document.querySelector(".manualDownload-text");
  const manualDownloadLink = document.querySelector(".manualDownload-link");
  var timeLeft = 20;

  downloadBtn.addEventListener("click", () => {
    downloadBtn.style.display = "none";
    countdown.innerHTML = "Your download will start in <span>" + timeLeft + "</span> seconds."  //for quick start of countdown

    var downloadTimer = setInterval(function timeCount() {
      timeLeft -= 1;
      countdown.innerHTML = "Your download will start in <span>" + timeLeft + "</span> seconds.";

      if(timeLeft <= 0){
        clearInterval(downloadTimer);
        pleaseWaitText.style.display = "block";

        setTimeout(() => {
          pleaseWaitText.style.display = "none";
        manualDownloadText.style.display = "block"
        }, 4000);
      }
    }, 1000);
  });

  </script>

@endsection

























