@extends('Layout.app')
@section('content')



<br><br>
<table class="table table-dark table-striped container">

  <tr >
    <th scope="row"><span></span></th>
    <th scope="row"><span>id</span></th>
    <th scope="row"><span>Language Name</span></th>
    <th scope="row"><span> Post id</span></th>
    <th scope="row"><span></span></th>
    <th scope="row"><span>Name Category</span></th>
    <th scope="row"><span></span></th>
    <th scope="3">Actions </th>

  </tr >
    @if ($language->count()>0 )
        @foreach ($language as $item)
            <tr class="container">
                <td ></td>
                <td >{{$item->id}}</td>
                <td >{{$item->language_Name}}</td>
                <td >{{$item->post_id}}</td>
                <td ></td>
                <td >{{$item->Category_Name}}</td>
                <td ></td>
                <td >
                    <a  class="btn btn-danger" href="{{route('language.delete',['id'=>$item->id])}}">
                        <i class="fa fa-trash" ></i>
                    </a>
                    <a  class="btn btn-warning" href="{{route('language.edit',['id'=>$item->id])}}">
                        <i class="fa fa-edit"></i>
                    </a>
                    <a  class="btn btn-info" href="{{route('language.create')}}"><i class="fa fa-user-plus"></i></a>
                </td>
            </tr>
        @endforeach
    @else
        <br><br><br><br><br><br><br>
        <a class="btn btn-info btn-add" href="{{route('language.create')}}"> Add category<i class="uil uil-user-plus"></i></a>
    @endif

</table>
    <div class="d-flex justify-content-center " style="margin:5% ">
        {!! $language->links('pagination::bootstrap-4') !!}
    </div>
<br><br><br><br>
@endsection

