@extends('Layout.app')
@section('content')

<div class="container p-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('language.update',['id'=>$language->id]) }}" enctype="multipart/form-data">
                        @csrf
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end"> Post id </label>
                            <div class="col-md-6">
                                <select class="form-select " name="post_id_vw">
                                    @foreach ($posts as $post )
                                        @if ($post->id ==$language->post_id )
                                            <option value="{{$post->id}}">{{$post->post_name}}</option>
                                        @endif
                                    @endforeach
                                </section>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end"> Language Name </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" value="{{$language->language_Name}}" name="language_name_vw">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Language Code </label>
                            <div class="col-md-6">
                                <textarea name="language_code_vw" class="form-control" cols="30" rows="10">{{$language->language_code}}</textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Description </label>
                            <div class="col-md-6">
                                <textarea name="language_about_vw"  class="form-control" cols="30" rows="10">{{$language->language_about}}</textarea>
                            </div>
                        </div>


                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<br><br><br><br>
@endsection
