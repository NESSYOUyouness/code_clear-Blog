<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="{{asset('Dashboard/style.css') }}">

	<title> Dashboard </title>
</head>
<body>


<!-- SIDEBAR -->
<section id="sidebar">
	<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
	</a>
	<ul class="side-menu top">
			<li class="active">
				<a href="{{route('post.index')}}">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Home</span>
				</a>
			</li>
			<li>
				<a href="{{route('posts.listpost')}}">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">Add Post</span>
				</a>
			</li>
			<li>
				<a href="{{route('category.index')}}">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Add Category</span>
				</a>
			</li>
			<li>
				<a href="{{route('language.index')}}">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Add Language</span>
				</a>
			</li>

	</ul>
	<ul class="side-menu">
		<li>
			{{-- <a href="#" class="logout"> --}}


				{{-- <span class="text">Logout</span> --}}
                <a class="class="logout" href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <i class='bx bxs-log-out-circle' ></i>
                    <span class="text">Logout</span>

                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
		</li>
	</ul>

</section>
<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Posts</a>


			<form action="{{ route('post.index') }}" method="GET" >
				<div class="form-input">
					<input type="search" placeholder="Search..." name="search">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>




			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			{{-- <a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a> --}}
			<a href="#" class="profile">
				<img src="{{asset('assets/img/code3.png') }}">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">

                        <li>
							<a class="active" href="{{route('post.index')}}">Home</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
                        <li>
							<a>{{  request()->route()->getName() }} </a>
 						</li>



					</ul>
				</div>

			</div>

			<ul class="box-info">
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
						<h3>{{$posts->count()}}</h3>
						<p>Posts</p>
					</span>
				</li>
				<li>
					<i class='bx bxs-group' ></i>
					<span class="text">
						<h3>{{$users->count()}}</h3>
						<p>Users</p>
					</span>
				</li>
				<li>
                    {{-- bx bxs-dollar-circle  --}}
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">
						<h3>{{$categorys->count()}}</h3>
						<p>Categories</p>
					</span>
				</li>
			</ul>
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Recent works</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Posts</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
                            @foreach ($top_post_5 as $item)
                                <tr>
                                    <td>
                                        <img src="/{{$item->avatar}}">
                                        <p>{{$item->post_name}}</p>
                                    </td>
                                    <td>{{ \Carbon\Carbon::parse($item->created_at)->format('d:m:Y')}}</td>
                                    <td><span class="status completed">Completed</span></td>
                                </tr>
                            @endforeach
							{{-- <tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status process">Process</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr> --}}
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Todos</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<ul class="todo-list">

                        <li class="not-completed">
							<p>Posts</p>
							<i>{{$posts->count()}}</i>
						</li>
						<li class="completed">
							<p>Languages</p>
							<i>
                                @php
                                    $list1= [];
                                    for ($i=0; $i < $languages->count(); $i++) {
                                        $list1[$i] =$languages[$i]->language_Name ;
                                    }
                                    $arr_freq = array_count_values($list1);
                                    echo count($arr_freq) ;
                                @endphp
                                {{-- {{$languages->count()}} --}}
                            </i>
						</li>
						<li class="not-completed">
							<p>Categories</p>
							<i>{{$categorys->count()}}</i>
						</li>
                        <li class="completed">
							<p>Users</p>
							<i>{{$users->count()}}</i>
						</li>

					</ul>
				</div>
			</div>
		</main>
		<!-- MAIN -->
</section>
<!-- CONTENT -->

<script src="{{asset('Dashboard/script.js')}}"></script>

</body>
</html>
