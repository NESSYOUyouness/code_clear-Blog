@extends('Layout.app')
@section('content')


    <div class="banner-area banner-inner-1 bg-black" id="banner">

            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    @foreach ( $posts as $post )
                    <div class="carousel-item active">
                        <div class="banner-inner pt-5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="thumb after-left-top">
                                            <img src="/{{$post->avatar}}" alt="img">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 align-self-center">
                                        <div class="banner-details mt-4 mt-lg-0">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li>
                                                        <a class="tag-base tag-blue">
                                                            @foreach ($categorys as $category )
                                                                @if ($category->id == $post->category_id )
                                                                    {{$category->Category_Name}}
                                                                @endif
                                                            @endforeach
                                                        </a>
                                                    </li>
                                                    <li class="date"><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($post->created_at)->format('d:m:Y')}}</li>
                                                </ul>
                                            </div>
                                            <h2>{{$post->post_title}}</h2>
                                            <p> {{ substr($post->post_about, 0, 200)}} <b>...</b></p>
                                            <a class="btn btn-blue" href=" {{route('Post',['id'=>$post->id])}}">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @foreach ( $postsMov as $post )
                    <div class="carousel-item ">
                        <div class="banner-inner pt-5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="thumb after-left-top">
                                            <img src="/{{$post->avatar}}" alt="img">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 align-self-center">
                                        <div class="banner-details mt-4 mt-lg-0">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li><a class="tag-base tag-blue">
                                                        @foreach ($categorys as $category )
                                                            @if ($category->id == $post->category_id )
                                                                {{$category->Category_Name}}
                                                            @endif
                                                        @endforeach
                                                    </a></li>
                                                    <li class="date"><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($post->created_at)->format('d:m:Y')}}</li>
                                                </ul>
                                            </div>
                                            <h2>{{$post->post_title}}</h2>
                                            <p> {{ substr($post->post_about, 0, 200)}} <b>...</b></p>
                                            <a class="btn btn-blue" href=" {{route('Post',['id'=>$post->id])}}">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>


            <!-- banner area end -->
            <div class="container">
                <div class="row">
                    @if($postsFour->isNotEmpty())
                        @foreach ($postsFour as $post4 )
                            <div class="col-lg-3 col-sm-6">
                                <div class="single-post-wrap style-white">
                                    <div class="thumb">
                                        <img src="/{{$post4->avatar}}" alt="img">
                                        <a class="tag-base tag-blue" >
                                            @foreach ($categorys as $category )
                                                @if ($category->id == $post4->category_id )
                                                    {{$category->Category_Name}}
                                                @endif
                                            @endforeach
                                        </a>
                                    </div>
                                    <div class="details">
                                        <h6 class="title"><a href="{{route('Post',['id'=>$post4->id])}}">{{$post4->post_title}} </a> </h6>
                                        <div class="post-meta-single mt-3">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($post4->created_at)->format('d:m:Y')}}</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div center>
                            <h5 style="color: red ">Search failed, please try again</h5>
                        </div>
                    @endif

                </div>
            </div>
    </div>

    <!-- banner area end -->

    <div class="post-area pd-top-75 pd-bottom-50" id="trending" style="background:#ecf0f1 ">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Trending News</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            <div class="trending-post">
                                @foreach ($postsCateg3 as $postsCateg )

                                <div class="single-post-wrap style-overlay">
                                    <div class="thumb">
                                        <img src="/{{$postsCateg->avatar}}" alt="img">
                                    </div>
                                    <div class="details">
                                        <div class="post-meta-single">
                                            <p><i class="fa fa-clock-o"></i>{{ date('l', time())}} {{ date('d'); }}  , {{ date('Y') }}</p>
                                        </div>
                                        <h6 class="title"><a href="href=" {{route('Post',['id'=>$postsCateg->id])}}">{{$postsCateg->post_title}}</a></h6>
                                    </div>
                                </div>

                                @endforeach

                            </div>
                        </div>
                        <div class="item">
                            <div class="trending-post">
                                @foreach ($postsCateg4 as $postsCateg )
                                <div class="single-post-wrap style-overlay">
                                    <div class="thumb">
                                        <img src="/{{$postsCateg->avatar}}" alt="img">
                                    </div>
                                    <div class="details">
                                        <div class="post-meta-single">
                                            <p><i class="fa fa-clock-o"></i>{{ date('l', time())}} {{ date('d'); }}  , {{ date('Y') }}</p>
                                        </div>
                                        <h6 class="title"><a href="href=" {{route('Post',['id'=>$postsCateg->id])}}">{{$postsCateg->post_title}}</a></h6>
                                    </div>
                                </div>

                                @endforeach

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Latest News</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            @foreach ($posts5_move as $posts5 )
                                <div class="single-post-list-wrap">
                                    <div class="media">
                                        <div class="media-left">
                                            <img src="{{$posts5->avatar}}" alt="img">
                                        </div>
                                        <div class="media-body">
                                            <div class="details">
                                                <div class="post-meta-single">
                                                    <ul>
                                                        <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($posts5->created_at)->format('d:m:Y')}}</li>
                                                    </ul>
                                                </div>
                                                <h6 class="title"><a href="{{route('Post',['id'=>$posts5->id])}}">{{$posts5->post_title}}</a></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="item">
                            @foreach ($posts5_move2 as $posts5 )
                            <div class="single-post-list-wrap">
                                <div class="media">
                                    <div class="media-left">
                                        <img src="/{{$posts5->avatar}}" alt="img">
                                    </div>
                                    <div class="media-body">
                                        <div class="details">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($posts5->created_at)->format('d:m:Y')}}</li>
                                                </ul>
                                            </div>
                                            <h6 class="title"><a href="{{route('Post',['id'=>$posts5->id])}}">{{$posts5->post_title}}</a></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">What’s new</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            @foreach ($postsBttm1 as $postsBttm1 )
                            <div class="single-post-wrap">
                                <div class="thumb">
                                    <img src="/{{$postsBttm1->avatar}}" alt="img">
                                </div>
                                <div class="details">
                                    <div class="post-meta-single mb-4 pt-1">
                                        <ul>
                                            <li><a class="tag-base tag-blue">
                                                @foreach ($categorys as $category )
                                                    @if ($category->id == $postsBttm1->category_id )
                                                        {{$category->Category_Name}}
                                                    @endif
                                                @endforeach
                                                </a>
                                            </li>
                                            <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($postsBttm1->created_at)->format('d:m:Y')}}</li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="{{route('Post',['id'=>$postsBttm1->id])}}">{{$postsBttm1->post_title}}</a></h6>
                                    <p> {{ substr($postsBttm1->post_about, 0, 100)}}... </p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        <div class="item">
                            @foreach ($postsBttm2 as $postsBttm1 )
                            <div class="single-post-wrap">
                                <div class="thumb">
                                    <img src="/{{$postsBttm1->avatar}}" alt="img">
                                </div>
                                <div class="details">
                                    <div class="post-meta-single mb-4 pt-1">
                                        <ul>
                                            <li><a class="tag-base tag-blue" >
                                                @foreach ($categorys as $category )
                                                    @if ($category->id == $postsBttm1->category_id )
                                                        {{$category->Category_Name}}
                                                    @endif
                                                @endforeach
                                                </a>
                                            </li>
                                            <li><i class="fa fa-clock-o"></i>{{ \Carbon\Carbon::parse($postsBttm1->created_at)->format('d:m:Y')}}</li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="{{route('Post',['id'=>$postsBttm1->id])}}">{{$postsBttm1->post_title}}</a></h6>
                                    <p> {{ substr($postsBttm1->post_about, 0, 200)}}... </p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Join With Us</h6>
                    </div>
                    <div class="social-area-list mb-4">
                        <ul>
                            <li><a class="facebook" href="#"><i class="fa fa-facebook social-icon"></i><span>12,300</span><span>Like</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="twitter" href="#"><i class="fa fa-twitter social-icon"></i><span>12,600</span><span>Followers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="youtube" href="#"><i class="fa fa-youtube-play social-icon"></i><span>1,300</span><span>Subscribers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="instagram" href="#"><i class="fa fa-instagram social-icon"></i><span>52,400</span><span>Followers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="google-plus" href="#"><i class="fa fa-google social-icon"></i><span>19,101</span><span>Subscribers</span> <i class="fa fa-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="add-area">
                        <a href="#"><img class="w-100" src="assets/img/add/6.png" alt="img"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-sky pd-top-80 pd-bottom-50" id="latest">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-sm-6">
                    @foreach ($postsBttm as $postsBttm )
                        <div class="single-post-wrap style-overlay-bg">
                            <div class="thumb">
                                <img src="{{$postsBttm->avatar}}" alt="img">
                            </div>
                            <div class="details">
                                <div class="post-meta-single mb-3">
                                    <ul>
                                        <li><a class="tag-base tag-blue" href="cat-fashion.html">
                                            @foreach ($categorys as $category )
                                                @if ($category->id == $postsBttm->category_id )
                                                    {{$category->Category_Name}}
                                                @endif
                                            @endforeach
                                        </a></li>
                                        <li><p><i class="fa fa-clock-o"></i>{{\Carbon\Carbon::parse($postsBttm->created_at)->format('d:m:Y')}}</p></li>
                                    </ul>
                                </div>
                                <h6 class="title"><a href="{{route('Post',['id'=>$post->id])}}">{{$postsBttm->post_title}}</a></h6>
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="col-lg-3 col-sm-6">
                    @foreach ($postsBttm_last1 as $postsBttm_last )
                        <div class="single-post-wrap">
                            <div class="thumb">
                                <img src="{{$postsBttm_last->avatar}}" alt="img">
                                <p class="btn-date"><i class="fa fa-clock-o"></i>
                                    {{ \Carbon\Carbon::parse($postsBttm_last->created_at)->format('d:m:Y')}}
                                </p>
                            </div>
                            <div class="details">
                                <h6 class="title"><a href="{{route('Post',['id'=>$postsBttm_last->id])}}">{{$postsBttm_last->post_title}}</a></h6>
                            </div>
                        </div>
                    @endforeach

                </div>
                <div class="col-lg-3 col-sm-6">
                    @foreach ($postsBttm_last2 as $postsBttm_last )
                        <div class="single-post-wrap">
                            <div class="thumb">
                                <img src="{{$postsBttm_last->avatar}}" alt="img">
                                <p class="btn-date"><i class="fa fa-clock-o"></i>
                                    {{ \Carbon\Carbon::parse($postsBttm_last->created_at)->format('d:m:Y')}}
                                </p>
                            </div>
                            <div class="details">
                                <h6 class="title"><a href="{{route('Post',['id'=>$postsBttm_last->id])}}">{{$postsBttm_last->post_title}}</a></h6>
                            </div>
                        </div>
                    @endforeach

                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="trending-post style-box">
                        <div class="section-title">
                            <h6 class="title">Trending News</h6>
                        </div>
                        <div class="post-slider owl-carousel">
                            <div class="item">
                                @foreach ($postsCateg5 as $postsCateg )
                                    <div class="single-post-list-wrap">
                                        <div class="media">
                                            <div class="media-left">
                                                <img src="{{$postsCateg->avatar}}" alt="img">
                                            </div>
                                            <div class="media-body">
                                                <div class="details">
                                                    <div class="post-meta-single">
                                                        <ul>
                                                            <li><i class="fa fa-clock-o"></i>{{ date('l', time())}} {{ date('d'); }}  , {{ date('Y') }}</li>
                                                        </ul>
                                                    </div>
                                                    <h6 class="title"><a href=" {{route('Post',['id'=>$postsCateg->id])}}">{{$postsCateg->post_name}}</a></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <div class="item">
                                @foreach ($postsCateg6 as $postsCateg )
                                    <div class="single-post-list-wrap">
                                        <div class="media">
                                            <div class="media-left">
                                                <img src="{{$postsCateg->avatar}}" alt="img">
                                            </div>
                                            <div class="media-body">
                                                <div class="details">
                                                    <div class="post-meta-single">
                                                        <ul>
                                                            <li><i class="fa fa-clock-o"></i>{{ date('l', time())}} {{ date('d'); }}  , {{ date('Y') }}</li>
                                                        </ul>
                                                    </div>
                                                    <h6 class="title"><a href=" {{route('Post',['id'=>$postsCateg->id])}}">{{$postsCateg->post_name}}</a></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="pd-top-80 pd-bottom-50" id="grid" style="background: #ecf0f1">
        <div class="container">
            <div class="row">
                @foreach ($posts88 as $post )
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-post-wrap style-overlay">
                            <div class="thumb">
                                <img src="{{$post->avatar}}" alt="img">
                                <a class="tag-base tag-purple" href="#">
                                    @foreach ($categorys as $category )
                                        @if ($category->id == $post->category_id )
                                            {{$category->Category_Name}}
                                        @endif
                                    @endforeach
                                </a>
                            </div>
                            <div class="details">

                                <h6 class="title"><a href="{{route('Post',['id'=>$post->id])}}">{{$post->post_title}}</a></h6>
                            </div>
                        </div>
                    </div>

                @endforeach

            </div>
        </div>
        <div class="d-flex justify-content-center " style="margin:5% ">
            {!! $posts88->links('pagination::bootstrap-4') !!}
        </div>
    </div>

@endsection
