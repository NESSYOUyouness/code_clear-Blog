
<div class="footer-area bg-black pd-top-95">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="widget">
                    <h5 class="widget-title">ABOUT US</h5>
                    <div class="widget_about">
                        <p>
                            My name is Youness. Professional web developer and professional web designer for years. I can build a website from scratch or update the site or anything that can be created with programming and I can fix issues with your current project or add a new feature to it.
                        </p>
                        <ul class="social-area social-area-2 mt-4">
                            <li><a class="facebook-icon" href="https://web.facebook.com/profile.php?id=100089620722577"><i class="fa fa-facebook" style="line-height: 30px;"></i></a></li>
                            <li><a class="youtube-icon" href="https://www.youtube.com/channel/UCNarH1np0G_w1ITLwxg3lVg"><i class="fa fa-youtube-play"style="line-height: 30px;"></i></a></li>
                            <li><a class="instagram-icon" href="https://www.instagram.com/code_clear/"><i class="fa fa-instagram"style="line-height: 30px;"></i></a></li>
                            <li><a class="google-icon" href="https://github.com/codeclear12/"><i class="fa fa-github" style="line-height: 30px;"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="widget widget_tag_cloud">
                    <h5 class="widget-title">TAGS</h5>
                    <div class="tagcloud">
                        <a>Front-End</a>
                        <a>Animation</a>
                        <a>HTML  </a>
                        <a>Website Design</a>
                        <a>Neumorphism</a>
                        <a>Design</a>
                        <a>CSS and JS</a>
                        <a>Form Design</a>

                        <a>Development</a>
                        <a>Card Design</a>

                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="widget">
                    <h5 class="widget-title">CONTACTS</h5>
                    <ul class="contact_info_list">
                        <li><i class="fa fa-map-marker"></i> Morocco</li>
                        <li><i class="fa fa-whatsapp"></i> +212 767555783</li>
                        <li><i class="fa fa-envelope-o"></i>scoormane7@gmail.com</li>
                        <li><i class="fa fa-address-card"></i> codeclear212@gmail.com </li>
                    </ul>

                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="widget widget_recent_post">
                    <h5 class="widget-title">MY SITES </h5>
                    <div class="single-post-list-wrap style-white">
                        <div class="media">
                            <div class="media-left">
                                <img src="{{asset('assets/img/post/list/2.png ') }}" alt="img">
                            </div>
                            <div class="media-body">
                                <div class="details">
                                    <div class="post-meta-single">
                                        <ul>
                                            <li><i class="fa fa-clock-o"></i>08.22.2023</li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="http://codeclear.byethost9.com/">My Facebook Page </a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-post-list-wrap style-white">
                        <div class="media">
                            <div class="media-left">
                                <img src="{{asset('assets/img/post/list/1.png') }}" alt="img">
                            </div>
                            <div class="media-body">
                                <div class="details">
                                    <div class="post-meta-single">
                                        <ul>
                                            <li><i class="fa fa-clock-o"></i>08.22.2020</li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="http://codeclear.byethost9.com/">My Own Website Where I post My Jobs</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom text-center">

            <p>Copyright ©2021 <a href="https://www.youtube.com/channel/UCNarH1np0G_w1ITLwxg3lVg">Code_Clear</a></p>
        </div>
    </div>
</div>

<!-- back to top area start -->
<div class="back-to-top">
    <span class="back-top"><i class="fa fa-angle-up"></i></span>
</div>
<!-- back to top area end -->

