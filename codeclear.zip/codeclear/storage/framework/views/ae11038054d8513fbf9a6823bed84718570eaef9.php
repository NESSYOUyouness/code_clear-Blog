<?php $__env->startSection('content'); ?>



<br><br>
<table class="table table-dark table-striped container">

  <tr >

    <th scope="row"><span></span></th>
    <th scope="row"><span>id</span></th>
    <th scope="row"><span></span></th>
    <th scope="row"><span> Post Link</span></th>
    <th scope="row"><span></span></th>
    <th scope="row"><span>Post Name</span></th>
    <th scope="row"><span> Category id</span></th>
    <th scope="3"> </th>
    <th scope="3">Actions </th>
    <th scope="3"> </th>

  </tr >
    <?php if($posts->count()>0 ): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="container">
                <td ></td>
                <td ><?php echo e($item->id); ?></td>
                <td ></td>
                <td ><?php echo e($item->post_name); ?></td>
                <td ></td>
                <td ><?php echo e($item->post_link); ?> </td>
                <td ><?php echo e($item->category_id); ?></td>
                <td >
                    <a  class="btn btn-danger" href="<?php echo e(route('posts.delete',['id'=>$item->id])); ?>">
                        <i class="fa fa-trash" ></i>
                    </a>
                </td>
                <td >
                    <a  class="btn btn-warning" href="<?php echo e(route('posts.edit',['id'=>$item->id])); ?>">
                        <i class="fa fa-edit"></i>
                    </a>
                </td>
                <td >
                    <a  class="btn btn-info" href="<?php echo e(route('post.create')); ?>"><i class="fa fa-user-plus"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <br><br><br><br><br><br><br>
        <a class="btn btn-info btn-add" href="<?php echo e(route('post.create')); ?>"> Add category<i class="uil uil-user-plus"></i></a>
    <?php endif; ?>

</table>
<?php echo $posts->links('pagination::bootstrap-4'); ?>

<br><br><br><br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/Post/index.blade.php ENDPATH**/ ?>