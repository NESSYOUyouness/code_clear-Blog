<?php $__env->startSection('content'); ?>

    <link href="<?php echo e(asset('assets2/css/bootstrap.css ')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('assets2/style.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('assets2/css/animate.css ')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets2/css/responsive.css ')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets2/css/colors.css ')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets2/css/version/marketing.css ')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('codeeditor/index.css')); ?>">


  <div id="wrapper">
    <section class="section lb">
        <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">

                <div class="page-wrapper">
                        <div class="blog-list-widget-blog ">
                            <div class="list-group">
                                <?php $__currentLoopData = $posts_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemTwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="w-100 justify-content-between">
                                        <img src="/<?php echo e($itemTwo->avatar); ?>" class="img-fluid float-left">
                                        <a href="<?php echo e(route('Post',['id'=>$itemTwo->post_id])); ?>">
                                            <h5 class="mb-1-blog"><?php echo e($itemTwo->post_title); ?></h5>
                                            <small>
                                            <i class="fa fa-clock-o"></i>
                                                <?php echo e(\Carbon\Carbon::parse($itemTwo->created_at)->format('d:m:Y')); ?>

                                            </small>
                                            <p class="mb-2-blog"> <?php echo e(substr($itemTwo->post_about, 0, 90)); ?>.. </p>
                                        </a>
                                    </div>
                                    <hr class="br-blog">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-center " style="margin:5%  ; color: white;">
                                    <?php echo $posts_blog->links('pagination::bootstrap-4'); ?>

                                </div>
                                <style>
                                    .pagination .page-item .page-link{
                                        color: white;
                                    }

                                    .br-blog{
                                        margin: 10px 10px 30px 10px;
                                    }

                                    .mb-2-blog{
                                        font-weight: 200;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 14px;
                                    }
                                    .mb-1-blog{
                                        margin-top: 8px;
                                        font-weight: 900;
                                        line-height: 1.4;
                                        color: #111111;
                                        font-size: 21px;
                                    }
                                    .blog-list-widget-blog img {
                                        margin-right: 15px;
                                        margin-bottom: 18px;
                                        max-width: 250px;
                                        max-height: 390px;
                                        border-radius: 10px;
                                        padding: 4px;
                                        border: none;
                                        width: 250px;
                                        height: 150px;
                                    }
                                </style>
                            </div>
                        </div>
                 </div>
                <hr class="invis">

            </div><!-- end col -->
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="sidebar">
                    <div class="widget">
                        <h2 class="widget-title">Recent Posts</h2>
                        <div class="blog-list-widget">
                            <div class="list-group">
                                <?php $__currentLoopData = $postsTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('Post',['id'=>$item->id])); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
                                        <div class="w-100 justify-content-between">
                                            <a href="<?php echo e(route('Post',['id'=>$item->id])); ?>">
                                                <img src="/<?php echo e($item->avatar); ?>" alt="" class="img-fluid float-left">
                                                <h5 class="mb-1"><?php echo e($item->post_title); ?></h5>

                                            <small>
                                                <a href="#"><i class="fa fa-clock-o"></i>
                                                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d:m:Y')); ?>

                                                </a>
                                            </small>
                                        </a>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <style>
                        .mb-1{
                            margin-top: -20px
                        }
                    </style>

                    <div id="" class="widget">
                                    <h2 class="widget-title">The Last Project</h2>
                                    <div class="banner-spot clearfix">
                                        <div class="banner-img">
                                            <?php $__currentLoopData = $last_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="banner-img">
                                                    <img src="/<?php echo e($last->avatar); ?>" class="img-last">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <style>
                                                .img-last{
                                                    max-width: 300px;
                                                    border-radius: 8px;
                                                    height: 200px;
                                                }
                                            </style>
                                        </div>
                                    </div><!-- end banner -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Most Popular </h2>

                        <div class="instagram-wrapper clearfix">
                            <?php $__currentLoopData = $lost_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#">
                                    <img src="/<?php echo e($last->avatar); ?>" class="img-fluid-most">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <style>
                                .img-fluid-most{
                                max-width: 90px;
                                max-height: 90px;
                                height: 90px;
                                border-radius: 8px;
                            }
                            </style>
                        </div><!-- end Instagram wrapper -->
                    </div><!-- end widget -->

                    <div class="widget">
                        <h2 class="widget-title">Popular Categories</h2>
                        <div class="link-widget">
                            <ul>
                                <?php $__empty_1 = true; $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li>
                                        <?php echo e($Category->Category_Name); ?>

                                        <span class="badge badge-secondary"><?php echo e($Category->posts->count()); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><!-- end link-widget -->
                    </div><!-- end widget -->
                </div><!-- end sidebar -->
            </div><!-- end col -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
  </div><!-- end wrapper -->

  
    <script src="<?php echo e(asset('assets2/js/animate.js')); ?>"></script>

    <script src="https://cdn.staticfile.org/jquery/2.1.1-rc2/jquery.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script src="<?php echo e(asset('codeeditor/index.js')); ?>"></script>
    <script src="<?php echo e(asset('codeeditor/main.js ')); ?>"></script>


<?php $__env->stopSection(); ?>


























<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/Post/blog_category.blade.php ENDPATH**/ ?>