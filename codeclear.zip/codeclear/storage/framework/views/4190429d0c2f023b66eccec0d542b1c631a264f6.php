<?php $__env->startSection('content'); ?>


    <div class="banner-area banner-inner-1 bg-black" id="banner">

            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item active">
                        <div class="banner-inner pt-5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="thumb after-left-top">
                                            <img src="/<?php echo e($post->avatar); ?>" alt="img">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 align-self-center">
                                        <div class="banner-details mt-4 mt-lg-0">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li>
                                                        <a class="tag-base tag-blue">
                                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($category->id == $post->category_id ): ?>
                                                                    <?php echo e($category->Category_Name); ?>

                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </a>
                                                    </li>
                                                    <li class="date"><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d:m:Y')); ?></li>
                                                </ul>
                                            </div>
                                            <h2><?php echo e($post->post_title); ?></h2>
                                            <p> <?php echo e(substr($post->post_about, 0, 200)); ?> <b>...</b></p>
                                            <a class="btn btn-blue" href=" <?php echo e(route('Post',['id'=>$post->id])); ?>">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $postsMov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item ">
                        <div class="banner-inner pt-5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="thumb after-left-top">
                                            <img src="/<?php echo e($post->avatar); ?>" alt="img">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 align-self-center">
                                        <div class="banner-details mt-4 mt-lg-0">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li><a class="tag-base tag-blue">
                                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($category->id == $post->category_id ): ?>
                                                                <?php echo e($category->Category_Name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </a></li>
                                                    <li class="date"><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d:m:Y')); ?></li>
                                                </ul>
                                            </div>
                                            <h2><?php echo e($post->post_title); ?></h2>
                                            <p> <?php echo e(substr($post->post_about, 0, 200)); ?> <b>...</b></p>
                                            <a class="btn btn-blue" href=" <?php echo e(route('Post',['id'=>$post->id])); ?>">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            <!-- banner area end -->
            <div class="container">
                <div class="row">
                    <?php if($postsFour->isNotEmpty()): ?>
                        <?php $__currentLoopData = $postsFour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-sm-6">
                                <div class="single-post-wrap style-white">
                                    <div class="thumb">
                                        <img src="/<?php echo e($post4->avatar); ?>" alt="img">
                                        <a class="tag-base tag-blue" >
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($category->id == $post4->category_id ): ?>
                                                    <?php echo e($category->Category_Name); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </a>
                                    </div>
                                    <div class="details">
                                        <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$post4->id])); ?>"><?php echo e($post4->post_title); ?> </a> </h6>
                                        <div class="post-meta-single mt-3">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($post4->created_at)->format('d:m:Y')); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div center>
                            <h5 style="color: red ">Search failed, please try again</h5>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
    </div>

    <!-- banner area end -->

    <div class="post-area pd-top-75 pd-bottom-50" id="trending" style="background:#ecf0f1 ">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Trending News</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            <div class="trending-post">
                                <?php $__currentLoopData = $postsCateg3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsCateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="single-post-wrap style-overlay">
                                    <div class="thumb">
                                        <img src="/<?php echo e($postsCateg->avatar); ?>" alt="img">
                                    </div>
                                    <div class="details">
                                        <div class="post-meta-single">
                                            <p><i class="fa fa-clock-o"></i><?php echo e(date('l', time())); ?> <?php echo e(date('d')); ?>  , <?php echo e(date('Y')); ?></p>
                                        </div>
                                        <h6 class="title"><a href="href=" <?php echo e(route('Post',['id'=>$postsCateg->id])); ?>"><?php echo e($postsCateg->post_title); ?></a></h6>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="item">
                            <div class="trending-post">
                                <?php $__currentLoopData = $postsCateg4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsCateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-post-wrap style-overlay">
                                    <div class="thumb">
                                        <img src="/<?php echo e($postsCateg->avatar); ?>" alt="img">
                                    </div>
                                    <div class="details">
                                        <div class="post-meta-single">
                                            <p><i class="fa fa-clock-o"></i><?php echo e(date('l', time())); ?> <?php echo e(date('d')); ?>  , <?php echo e(date('Y')); ?></p>
                                        </div>
                                        <h6 class="title"><a href="href=" <?php echo e(route('Post',['id'=>$postsCateg->id])); ?>"><?php echo e($postsCateg->post_title); ?></a></h6>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Latest News</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            <?php $__currentLoopData = $posts5_move; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-post-list-wrap">
                                    <div class="media">
                                        <div class="media-left">
                                            <img src="<?php echo e($posts5->avatar); ?>" alt="img">
                                        </div>
                                        <div class="media-body">
                                            <div class="details">
                                                <div class="post-meta-single">
                                                    <ul>
                                                        <li><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($posts5->created_at)->format('d:m:Y')); ?></li>
                                                    </ul>
                                                </div>
                                                <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$posts5->id])); ?>"><?php echo e($posts5->post_title); ?></a></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="item">
                            <?php $__currentLoopData = $posts5_move2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post-list-wrap">
                                <div class="media">
                                    <div class="media-left">
                                        <img src="/<?php echo e($posts5->avatar); ?>" alt="img">
                                    </div>
                                    <div class="media-body">
                                        <div class="details">
                                            <div class="post-meta-single">
                                                <ul>
                                                    <li><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($posts5->created_at)->format('d:m:Y')); ?></li>
                                                </ul>
                                            </div>
                                            <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$posts5->id])); ?>"><?php echo e($posts5->post_title); ?></a></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">What’s new</h6>
                    </div>
                    <div class="post-slider owl-carousel">
                        <div class="item">
                            <?php $__currentLoopData = $postsBttm1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsBttm1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post-wrap">
                                <div class="thumb">
                                    <img src="/<?php echo e($postsBttm1->avatar); ?>" alt="img">
                                </div>
                                <div class="details">
                                    <div class="post-meta-single mb-4 pt-1">
                                        <ul>
                                            <li><a class="tag-base tag-blue">
                                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($category->id == $postsBttm1->category_id ): ?>
                                                        <?php echo e($category->Category_Name); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </a>
                                            </li>
                                            <li><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($postsBttm1->created_at)->format('d:m:Y')); ?></li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$postsBttm1->id])); ?>"><?php echo e($postsBttm1->post_title); ?></a></h6>
                                    <p> <?php echo e(substr($postsBttm1->post_about, 0, 100)); ?>... </p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="item">
                            <?php $__currentLoopData = $postsBttm2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsBttm1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post-wrap">
                                <div class="thumb">
                                    <img src="/<?php echo e($postsBttm1->avatar); ?>" alt="img">
                                </div>
                                <div class="details">
                                    <div class="post-meta-single mb-4 pt-1">
                                        <ul>
                                            <li><a class="tag-base tag-blue" >
                                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($category->id == $postsBttm1->category_id ): ?>
                                                        <?php echo e($category->Category_Name); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </a>
                                            </li>
                                            <li><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($postsBttm1->created_at)->format('d:m:Y')); ?></li>
                                        </ul>
                                    </div>
                                    <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$postsBttm1->id])); ?>"><?php echo e($postsBttm1->post_title); ?></a></h6>
                                    <p> <?php echo e(substr($postsBttm1->post_about, 0, 200)); ?>... </p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="section-title">
                        <h6 class="title">Join With Us</h6>
                    </div>
                    <div class="social-area-list mb-4">
                        <ul>
                            <li><a class="facebook" href="#"><i class="fa fa-facebook social-icon"></i><span>12,300</span><span>Like</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="twitter" href="#"><i class="fa fa-twitter social-icon"></i><span>12,600</span><span>Followers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="youtube" href="#"><i class="fa fa-youtube-play social-icon"></i><span>1,300</span><span>Subscribers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="instagram" href="#"><i class="fa fa-instagram social-icon"></i><span>52,400</span><span>Followers</span> <i class="fa fa-plus"></i></a></li>
                            <li><a class="google-plus" href="#"><i class="fa fa-google social-icon"></i><span>19,101</span><span>Subscribers</span> <i class="fa fa-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="add-area">
                        <a href="#"><img class="w-100" src="assets/img/add/6.png" alt="img"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-sky pd-top-80 pd-bottom-50" id="latest">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-sm-6">
                    <?php $__currentLoopData = $postsBttm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsBttm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-post-wrap style-overlay-bg">
                            <div class="thumb">
                                <img src="<?php echo e($postsBttm->avatar); ?>" alt="img">
                            </div>
                            <div class="details">
                                <div class="post-meta-single mb-3">
                                    <ul>
                                        <li><a class="tag-base tag-blue" href="cat-fashion.html">
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($category->id == $postsBttm->category_id ): ?>
                                                    <?php echo e($category->Category_Name); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </a></li>
                                        <li><p><i class="fa fa-clock-o"></i><?php echo e(\Carbon\Carbon::parse($postsBttm->created_at)->format('d:m:Y')); ?></p></li>
                                    </ul>
                                </div>
                                <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$post->id])); ?>"><?php echo e($postsBttm->post_title); ?></a></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <?php $__currentLoopData = $postsBttm_last1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsBttm_last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-post-wrap">
                            <div class="thumb">
                                <img src="<?php echo e($postsBttm_last->avatar); ?>" alt="img">
                                <p class="btn-date"><i class="fa fa-clock-o"></i>
                                    <?php echo e(\Carbon\Carbon::parse($postsBttm_last->created_at)->format('d:m:Y')); ?>

                                </p>
                            </div>
                            <div class="details">
                                <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$postsBttm_last->id])); ?>"><?php echo e($postsBttm_last->post_title); ?></a></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php $__currentLoopData = $postsBttm_last2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsBttm_last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-post-wrap">
                            <div class="thumb">
                                <img src="<?php echo e($postsBttm_last->avatar); ?>" alt="img">
                                <p class="btn-date"><i class="fa fa-clock-o"></i>
                                    <?php echo e(\Carbon\Carbon::parse($postsBttm_last->created_at)->format('d:m:Y')); ?>

                                </p>
                            </div>
                            <div class="details">
                                <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$postsBttm_last->id])); ?>"><?php echo e($postsBttm_last->post_title); ?></a></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="trending-post style-box">
                        <div class="section-title">
                            <h6 class="title">Trending News</h6>
                        </div>
                        <div class="post-slider owl-carousel">
                            <div class="item">
                                <?php $__currentLoopData = $postsCateg5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsCateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-post-list-wrap">
                                        <div class="media">
                                            <div class="media-left">
                                                <img src="<?php echo e($postsCateg->avatar); ?>" alt="img">
                                            </div>
                                            <div class="media-body">
                                                <div class="details">
                                                    <div class="post-meta-single">
                                                        <ul>
                                                            <li><i class="fa fa-clock-o"></i><?php echo e(date('l', time())); ?> <?php echo e(date('d')); ?>  , <?php echo e(date('Y')); ?></li>
                                                        </ul>
                                                    </div>
                                                    <h6 class="title"><a href=" <?php echo e(route('Post',['id'=>$postsCateg->id])); ?>"><?php echo e($postsCateg->post_name); ?></a></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="item">
                                <?php $__currentLoopData = $postsCateg6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postsCateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-post-list-wrap">
                                        <div class="media">
                                            <div class="media-left">
                                                <img src="<?php echo e($postsCateg->avatar); ?>" alt="img">
                                            </div>
                                            <div class="media-body">
                                                <div class="details">
                                                    <div class="post-meta-single">
                                                        <ul>
                                                            <li><i class="fa fa-clock-o"></i><?php echo e(date('l', time())); ?> <?php echo e(date('d')); ?>  , <?php echo e(date('Y')); ?></li>
                                                        </ul>
                                                    </div>
                                                    <h6 class="title"><a href=" <?php echo e(route('Post',['id'=>$postsCateg->id])); ?>"><?php echo e($postsCateg->post_name); ?></a></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="pd-top-80 pd-bottom-50" id="grid" style="background: #ecf0f1">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $posts88; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-post-wrap style-overlay">
                            <div class="thumb">
                                <img src="<?php echo e($post->avatar); ?>" alt="img">
                                <a class="tag-base tag-purple" href="#">
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->id == $post->category_id ): ?>
                                            <?php echo e($category->Category_Name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                            </div>
                            <div class="details">

                                <h6 class="title"><a href="<?php echo e(route('Post',['id'=>$post->id])); ?>"><?php echo e($post->post_title); ?></a></h6>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <div class="d-flex justify-content-center " style="margin:5% ">
            <?php echo $posts88->links('pagination::bootstrap-4'); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/welcome.blade.php ENDPATH**/ ?>