<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('Dashboard/style.css')); ?>">

	<title> Dashboard </title>
</head>
<body>


<!-- SIDEBAR -->
<section id="sidebar">
	<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
	</a>
	<ul class="side-menu top">
			<li class="active">
				<a href="<?php echo e(route('post.index')); ?>">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Home</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('posts.listpost')); ?>">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">Add Post</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('category.index')); ?>">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Add Category</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('language.index')); ?>">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Add Language</span>
				</a>
			</li>

	</ul>
	<ul class="side-menu">
		<li>
			


				
                <a class="class="logout" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <i class='bx bxs-log-out-circle' ></i>
                    <span class="text">Logout</span>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
		</li>
	</ul>

</section>
<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Posts</a>


			<form action="<?php echo e(route('post.index')); ?>" method="GET" >
				<div class="form-input">
					<input type="search" placeholder="Search..." name="search">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>




			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			
			<a href="#" class="profile">
				<img src="<?php echo e(asset('assets/img/code3.png')); ?>">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">

                        <li>
							<a class="active" href="<?php echo e(route('post.index')); ?>">Home</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
                        <li>
							<a><?php echo e(request()->route()->getName()); ?> </a>
 						</li>



					</ul>
				</div>

			</div>

			<ul class="box-info">
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
						<h3><?php echo e($posts->count()); ?></h3>
						<p>Posts</p>
					</span>
				</li>
				<li>
					<i class='bx bxs-group' ></i>
					<span class="text">
						<h3><?php echo e($users->count()); ?></h3>
						<p>Users</p>
					</span>
				</li>
				<li>
                    
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">
						<h3><?php echo e($categorys->count()); ?></h3>
						<p>Categories</p>
					</span>
				</li>
			</ul>
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Recent works</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Posts</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $top_post_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="/<?php echo e($item->avatar); ?>">
                                        <p><?php echo e($item->post_name); ?></p>
                                    </td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d:m:Y')); ?></td>
                                    <td><span class="status completed">Completed</span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Todos</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<ul class="todo-list">

                        <li class="not-completed">
							<p>Posts</p>
							<i><?php echo e($posts->count()); ?></i>
						</li>
						<li class="completed">
							<p>Languages</p>
							<i>
                                <?php
                                    $list1= [];
                                    for ($i=0; $i < $languages->count(); $i++) {
                                        $list1[$i] =$languages[$i]->language_Name ;
                                    }
                                    $arr_freq = array_count_values($list1);
                                    echo count($arr_freq) ;
                                ?>
                                
                            </i>
						</li>
						<li class="not-completed">
							<p>Categories</p>
							<i><?php echo e($categorys->count()); ?></i>
						</li>
                        <li class="completed">
							<p>Users</p>
							<i><?php echo e($users->count()); ?></i>
						</li>

					</ul>
				</div>
			</div>
		</main>
		<!-- MAIN -->
</section>
<!-- CONTENT -->

<script src="<?php echo e(asset('Dashboard/script.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/dashboard.blade.php ENDPATH**/ ?>