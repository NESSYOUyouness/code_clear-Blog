<div class="commentbox"></div>
<script src="https://unpkg.com/commentbox.io/dist/commentBox.min.js"></script>
<script>commentBox('my-project-id')</script>
<?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/include/comment.blade.php ENDPATH**/ ?>