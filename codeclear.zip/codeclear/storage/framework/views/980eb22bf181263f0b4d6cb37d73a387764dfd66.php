<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Code_Clear</title>
    <!-- favicon -->

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <!-- Fonts -->

    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <link rel=icon href="<?php echo e(asset('assets/img/favicon.png')); ?>" sizes="20x20" type="image/png">
    


  <!--=============== REMIX ICONS ===============-->

    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor.css ')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

     <!-- theme dark  -->
  </head>
<body>



    <?php echo $__env->make('include.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('include.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- all plugins here -->
    <script src="<?php echo e(asset('assets/js/vendor.js')); ?>"></script>
    <!-- main js  -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/layout/app.blade.php ENDPATH**/ ?>