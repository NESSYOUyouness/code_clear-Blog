<?php $__env->startSection('content'); ?>

<div class="container p-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('language.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label   class="col-md-4 col-form-label text-md-end"><?php echo e(__('Pote ')); ?></label>
                            <div class="col-md-6">

                                <select class="form-select " name="post_id_vw">
                                        <option value="<?php echo e($posts->id); ?>"><?php echo e($posts->post_name); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end"> Language Name </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" name="language_name_vw">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Language Code </label>
                            <div class="col-md-6">
                                <textarea name="language_code_vw"  class="form-control" cols="30" rows="10"></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Description </label>
                            <div class="col-md-6">
                                <textarea name="language_about_vw"  class="form-control" cols="30" rows="10"></textarea>
                            </div>
                        </div>


                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/LanguagePost/Create.blade.php ENDPATH**/ ?>