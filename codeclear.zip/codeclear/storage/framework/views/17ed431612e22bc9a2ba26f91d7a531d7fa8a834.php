<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row justify-content-center ">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action=" <?php echo e(route('post.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label   class="col-md-4 col-form-label text-md-end"><?php echo e(__('Category ')); ?></label>
                            <div class="col-md-6">

                                <select class="form-select " name="category_id_vw">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->Category_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label   class="col-md-4 col-form-label text-md-end"><?php echo e(__('Admin ')); ?></label>
                            <div class="col-md-6">

                                <select class="form-select " name="user_id_vw">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Name </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" name="name_post_vw">
                            </div>
                        </div>


                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Title </label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" name="post_title_view">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Image </label>
                            <div class="col-md-6">
                                <input  type="file" class="form-control" name="post_image_view">
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Post Description </label>
                            <div class="col-md-6">
                                <textarea name="post_dsrpt"  class="form-control" cols="30" rows="10"></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Link Youtube</label>
                            <div class="col-md-6">
                                <input  type="text" class="form-control" name="link_youtube">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-md-4 col-form-label text-md-end">Download File</label>
                            <div class="col-md-6">
                                <input  type="file" class="form-control" name="download_file_vw">
                            </div>
                        </div>



                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                                <a href="<?php echo e(route('category.create')); ?>" type="submit" class="btn btn-primary">
                                    <?php echo e(__('Add Category')); ?>

                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/Post/create.blade.php ENDPATH**/ ?>