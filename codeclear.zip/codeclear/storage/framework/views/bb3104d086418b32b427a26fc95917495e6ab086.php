
<!-- preloader area start -->
<div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div class="spinner">
                <div class="dot1"></div>
                <div class="dot2"></div>
            </div>
        </div>
</div>
<!-- search popup start-->
<div class="td-search-popup" id="td-search-popup">
        <form action="<?php echo e(route('post.index')); ?>" method="GET" class="search-form">
            <div class="form-group">
                <input type="text" name="search" class="form-control" placeholder="Search For .." required class="search-form-blog">
            </div>
            <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
        </form>
</div>

<!-- search popup end-->
<div class="body-overlay" id="body-overlay"></div>
<!-- header start -->
<div class="navbar-area">
        <!-- topbar end-->
        <div class="topbar-area">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-7 align-self-center">
                        <div class="topbar-menu text-md-left text-center">

                            <ul class="align-self-center">
                                <li><a><img src="<?php echo e(asset('assets/img/code2.png')); ?>"  style="width:70%;" alt="img"></a></a></li>
                                <?php if( Auth::user()): ?>
                                    <li><a href="<?php echo e(route('posts.listpost')); ?>">Add Post</a></li>
                                    <li><a href="<?php echo e(route('category.index')); ?>">Add Category</a></li>
                                    <li><a href="<?php echo e(route('language.index')); ?>">Add Language </a></li>
                                    <li><a href="#"> Dashboard </a></li>
                                <?php endif; ?>
                            </ul>


                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5 mt-2 mt-md-0 text-md-right text-center">
                        <div class="topbar-social">
                            <div class="topbar-date d-none d-lg-inline-block">
                                <i class="fa fa-calendar"></i>
                                <?php echo e(date('l', time())); ?> ,<?php echo e(date('F ',strtotime(''))); ?> <?php echo e(date('m')); ?>

                            </div>
                            <ul class="social-area social-area-22">
                                    <?php if(auth()->guard()->guest()): ?>
                                        <?php if(Route::has('login')): ?>
                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                            </li>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <li class="nav-item dropdown" style="width: 100px">
                                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                                <?php echo e(Auth::user()->name); ?>

                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                                    <?php echo e(__('Logout')); ?>

                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>

                                            </div>
                                        </li>
                                    <?php endif; ?>
                                <li><a ></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- topbar end-->

        <!-- adbar end-->
        <div class="adbar-area bg-black d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-5 align-self-center">
                        <div class="logo text-md-left text-center">
                            <a class="main-logo" href="index.html"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="img"></a>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-7 text-md-right text-center">
                        <a href="#" class="adbar-right">
                            <img src="<?php echo e(asset('assets/img/add/1.png ')); ?>" alt="img">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- adbar end-->

        <!-- navbar start -->
        <nav class="navbar navbar-expand-lg">
            <div class="container nav-container">
                <div class="responsive-mobile-menu">
                    <div class="logo d-lg-none d-block">
                        <a class="main-logo" href="index.html"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="img"></a>
                    </div>
                    <button class="menu toggle-btn d-block d-lg-none" data-target="#nextpage_main_menu"
                    aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-left"></span>
                        <span class="icon-right"></span>
                    </button>
                </div>
                <div class="nav-right-part nav-right-part-mobile">
                    <a class="search header-search" href="#"><i class="fa fa-search"></i></a>
                </div>
                <div class="collapse navbar-collapse" id="nextpage_main_menu">
                    <ul class="navbar-nav menu-open">
                        <li class="current-menu-item">
                            <a href="<?php echo e(route('post.index')); ?>">Home</a>
                        </li>
                        <li class="current-menu-item">
                            <a href="<?php echo e(route('post.blog')); ?>">BLOG</a>
                        </li>
                        <li class="current-menu-item">

                            <form action="<?php echo e(route('post.category')); ?>" method="GET" >
                                    <input type="text" value="HTML" name="Category" class="input" >
                                    <button type="submit" class="button-category" > HTML & CSS </button>
                            </form>
                        </li>
                            <style>
                                .button-category{
                                    border: none;
                                    background: var(--main-color);
                                    color: white;
                                    cursor:pointer;
                                }
                                .button-category:hover{
                                    color:#3197d6 !important;
                                    transition: 0.4s;
                                }

                                .input {
                                    width: 0px;
                                    opacity: 0;
                                }
                                .search-form-blog{
                                    display: inline;
                                }
                            </style>
                        &nbsp;&nbsp;

                        <li class="current-menu-item">
                            <form action="<?php echo e(route('post.category')); ?>" method="GET" >
                                <input type="text" value="JavaScript" name="Category" class="input" >
                                <button type="submit" class="button-category" > JAVASCRIPT </button>
                            </form>
                        </li>
                        <li class="current-menu-item">
                            <a href="<?php echo e(route('post.blog')); ?>#contact ">Contact us</a>
                        </li>
                    </ul>
                </div>
                <div class="nav-right-part nav-right-part-desktop">
                    <div class="menu-search-inner">
                        <form action="<?php echo e(route('post.index')); ?>" method="GET" class="search-form">
                            <input type="text" name="search" placeholder="Search For .." required class="search-form-blog">
                            <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                </div>

                <div class="td-search-popup" id="td-search-popup">


            </div>
            </div>
        </nav>
</div>
<!-- navbar end -->


<?php /**PATH C:\Users\youne\OneDrive\Desktop\laraveller\codeclear\resources\views/include/Header.blade.php ENDPATH**/ ?>