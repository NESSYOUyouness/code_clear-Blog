<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\PostController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\RegisterController;

use App\Http\Controllers\Controller;

Route::get('/', [PostController::class, 'index'])->name('post.index');
Route::get('posts/category', [PostController::class, 'blog_category'])->name('post.category');
Route::get('Post/{id}', [PostController::class, 'Post'])->name('Post');
Route::get('posts/blog/', [PostController::class, 'blog'])->name('post.blog');

Route::group(['middleware' => 'auth'], function () {

//--------------------Region posts ---------------------//

Route::get('posts/index', [PostController::class, 'listpost'])->name('posts.listpost');
Route::get('posts/create', [PostController::class, 'create'])->name('post.create');
Route::post('posts/store', [PostController::class, 'store'])->name('post.store');
Route::get('posts/delete/{id}', [PostController::class, 'destroy'])->name('posts.delete');
Route::get('posts/edit/{id}', [PostController::class, 'edit'])->name('posts.edit');
Route::post('posts/update/{id}', [PostController::class, 'update'])->name('posts.update');
//-------------------- End Region posts ---------------------//

//--------------------Region Category ---------------------//
Route::get('category/index', [CategoryController::class, 'index'])->name('category.index');
Route::get('category/create', [CategoryController::class, 'create'])->name('category.create');
Route::post('category/store', [CategoryController::class, 'store'])->name('category.store');
Route::get('category/delete/{id}', [CategoryController::class, 'destroy'])->name('category.delete');
Route::get('category/edit/{id}', [CategoryController::class, 'edit'])->name('category.edit');
Route::post('category/update/{id}', [CategoryController::class, 'update'])->name('category.update');


//-------------------- End Region Category ---------------------//

//--------------------Region posts ---------------------//

Route::get('language/index', [LanguageController::class, 'index'])->name('language.index');
Route::get('language/create', [LanguageController::class, 'create'])->name('language.create');
Route::post('language/store', [LanguageController::class, 'store'])->name('language.store');
Route::get('language/delete/{id}', [LanguageController::class, 'destroy'])->name('language.delete');
Route::get('language/edit/{id}', [LanguageController::class, 'edit'])->name('language.edit');
Route::post('language/update/{id}', [LanguageController::class, 'update'])->name('language.update');
//-------------------- End Region posts ---------------------//


Route::get('dashboardAdmin', [App\Http\Controllers\HomeController::class, 'dashboard'])->name('Dashboard');

});

// -----------------------------login-----------------------------------------
Auth::routes();

Route::any('registerAdmin', 'App\Http\Controllers\Auth\RegisterController@showRegistrationForm');
Route::post('registerAdmin', 'App\Http\Controllers\Auth\RegisterController@register');


if (env('ALLOW_USER_REGISTRATION', false))
{
    Route::get('register', 'App\Http\Controllers\Auth\RegisterController@showRegistrationForm')->name('register');
    Route::post('register', 'App\Http\Controllers\Auth\RegisterController@register');
}
else
{
    Route::match(['get','post'], 'register', function () {
        return view('errors404');
    })->name('register');
}

