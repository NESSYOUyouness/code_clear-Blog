<?php

namespace App\Http\Controllers;

use App\Models\Language;
use App\Models\Post;
use Illuminate\Http\Request;

class LanguageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {

        $language = Language::latest()->paginate(8);
        return view('LanguagePost.Index',compact('language'));
    }

    public function create()
    {
        $posts = Post::query()->orderBy('id', 'desc')->first();
        return view("LanguagePost.Create ",compact('posts'));
    }


    public function store(Request $request)
    {
        $this->validate($request,[
            'language_name_vw'=>'required',
            'language_about_vw'=>'required',
            'language_code_vw'=>'required',
        ]);

        $category = Language::create([
            'language_Name'      => $request->language_name_vw,
            'language_about'     => $request->language_about_vw,
            'language_code' => $request->language_code_vw,
            'post_id'            => $request->post_id_vw
        ]);


        $category->save();
        return  redirect('language/index');

    }

    public function edit($id)
    {
        $language = Language::find($id);
        $posts = Post::all();

        return view("LanguagePost.Editlanguage",compact("language",'posts'));
    }
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'language_name_vw'=>'required',
            'language_about_vw'=>'required',
            'language_code_vw'=>'required',
        ]);


        $language = Language::find($id);

        $language->language_Name    = $request->language_name_vw;
        $language->language_about     = $request->language_about_vw;
        $language->language_code = $request->language_code_vw;
        $language->post_id        = $request->post_id_vw;

        $language->save();
        return  redirect('language/index');
    }
    public function destroy( $id)
    {
        $language = Language::find($id);
        $language->Delete();
        return redirect()->back();;
    }
}
