<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
// use Illuminate\Support\Facades\Route;

// use App\Models\Post;
// use App\Models\Category;
// use App\Models\Language;



class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    // public function index(){

    //     // $posts = Post::all();
    //     $posts = Post::limit(1)->get();
    //     $postsTwo = Post::limit(3)->get();
    //     $postsThree = Post::limit(8)->get();


    //     $languages = Language::all();
    //     $categorys = Category::all();



    //     return view('Post.Post',compact('posts','languages','categorys','postsTwo','postsThree'));
    // }
}
