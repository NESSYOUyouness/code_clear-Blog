<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
use App\Models\User;
use App\Models\Language;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function dashboard()
    {
        $posts = Post::all();
        $categorys = Category::all();
        $users = User::all();
        $languages = Language::all();
        $top_post_5 = Post::paginate(8);

        return view('dashboard',compact('posts','categorys',
        'users','languages','top_post_5'));
    }
}
