<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Category;
use App\Models\User;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{

    public function index( Request $request)
    {

        $search = $request->input('search');

        $posts_blog = Post::query()
        ->where('post_name', 'LIKE', "%{$search}%")
        ->orWhere('post_title', 'LIKE', "%{$search}%")
        ->paginate(8);


        $posts = Post::orderBy('id', 'DESC')->paginate(1);
        $postsMov = Post::all();
        $posts88 = Post::paginate(8);
        $postsTwo = Post::limit(3)->get();
        $postsFour = Post::limit(4)->get();

        $postsThree = Post::limit(8)->get();
        $languages = Language::all();
        $categorys = Category::all();
        //---------------------------//
        //---------------------------//
        $postsCateg3 = DB::table('posts')->whereBetween('id', [2, 4])->get();
        //---------------------------//
        //---------------------------//
        $postsCateg4 = DB::table('posts')->whereBetween('id', [4, 6])->get();
        //---------------------------//
        //---------------------------//
        $postsCateg5 = DB::table('posts')->whereBetween('id', [1, 3])->get();
        //---------------------------//
        //---------------------------//
        $postsCateg6 = DB::table('posts')->whereBetween('id', [4, 6])->get();
        //---------------------------//
        //---------------------------//
        $postsBttm1 = DB::table('posts')->whereBetween('id', [2, 2])->get();
        //-------------------------//
        //-------------------------//
        $postsBttm = DB::table('posts')->whereBetween('id', [3,3])->get();
        //-------------------------//
        //-------------------------//
        $postsBttm2 = DB::table('posts')->whereBetween('id', [4, 4])->get();
        //-------------------------//
        //-------------------------//
        $postsBttm_last1 = DB::table('posts')->whereBetween('id', [1, 2])->get();
        $postsBttm_last2 = DB::table('posts')->whereBetween('id', [3, 4])->get();
        //------------------------//
        //------------------------//
        $posts5_move = Post::orderBy('id', 'DESC')->paginate(5);
        $posts5_move2 = Post::orderBy('id', 'ASC')->paginate(5);

        $last_project = Post::orderBy('id', 'DESC')->paginate(1);
        $lost_popular = Post::orderBy('id', 'DESC')->paginate(9);





        if ($search == null) {

        return view('welcome',compact('posts','languages','categorys','postsMov',
        'postsTwo','postsThree','postsFour','postsCateg3','posts5_move','posts5_move2',
        'postsBttm1','postsBttm2' ,'postsCateg4','postsCateg6','postsCateg5','postsBttm',
        'postsBttm_last1', 'postsBttm_last2','posts88','posts_blog' ));
        } else {
            return view("Post.blog",compact('postsTwo','posts_blog','last_project' ,'lost_popular','categorys'));
        }
    }

    public function listpost(){
        $posts = Post::latest()->paginate(8);
        return view('Post.index' , compact('posts'));
    }
    public function blog( Request $request)
    {
        $search = $request->input('search');
        $categorys = Category::all();
        $postsTwo = Post::limit(3)->get();
        $posts_blog = Post::paginate(8);
        $last_project = Post::orderBy('id', 'DESC')->paginate(1);
        $lost_popular = Post::orderBy('id', 'DESC')->paginate(9);


        $posts_blog = Post::query()
        ->where('post_name', 'LIKE', "%{$search}%")
        ->orWhere('post_title', 'LIKE', "%{$search}%")
        ->paginate(8);

        return view("Post.blog",compact('postsTwo','posts_blog','last_project' ,'lost_popular','categorys'));
    }
    public function blog_category( Request $request)
    {
        $search1 = $request->Category;

        $category  = Category::all();
        $postsTwo = Post::limit(3)->get();
        $last_project = Post::orderBy('id', 'DESC')->paginate(1);
        $categorys = Category::all();
        $lost_popular = Post::orderBy('id', 'DESC')->paginate(9);


        if($search1 != 'JavaScript')
            $posts_blog = DB::table('posts')
            ->join('languages', 'posts.id', '=', 'languages.post_id')
            ->Where('languages.language_Name', 'LIKE', "%{$search1}%")
            ->Where('posts.post_title', 'NOt LIKE', "%JavaScript%")
            ->paginate(8);
        else  {
            $posts_blog = DB::table('posts')
            ->join('languages', 'posts.id', '=', 'languages.post_id')
            ->Where('languages.language_Name', 'LIKE', "%{$search1}%")
            ->paginate(8);
        }






        return view("Post.blog_category",compact('postsTwo','posts_blog',
        'last_project','lost_popular','categorys' ));
    }
    public function Post($id){

        $post = Post::find($id);
        $postsTwo = Post::limit(3)->get();
        $postsThree = Post::limit(8)->get();
        $last_project =  DB::table('posts')->whereBetween('id', [2, 2])->get();
        $lost_popular = Post::orderBy('id', 'DESC')->paginate(9);

        $languages = Language::all();
        $categorys = Category::all();


        return view('Post.Post',compact('post','languages','categorys',
                    'postsTwo','postsThree','last_project','lost_popular'));
    }


    public function create()
    {
        $category = Category::all();

        $users = User::all();
        return view("Post.create",compact('category','users'));
    }


    public function store(Request $request)
    {

        $this->validate($request,[
            'name_post_vw'           =>'required',
            'post_title_view'        =>'required',
            'post_dsrpt'             =>'required' ,
            'link_youtube'           =>'required',
            'download_file_vw'       => 'required|file|mimes:jpg,jpeg,bmp,png,doc,docx,csv,rtf,xlsx,xls,txt,pdf,zip',
            'post_image_view'        =>"required|image|mimes:jpg,jpag,gif,png|max:2048",

        ]);

        $photo = $request->post_image_view ;
        $photo_new_name = time().$photo->getClientOriginalName();
        $photo->move('uploads/PostImage/',$photo_new_name);

           #-------- upload PDF file -----------#
           $download_file = $request->download_file_vw ;
           $file_new_name = time().$download_file->getClientOriginalName();
           $download_file->move('uploads/Downloads_File/',$file_new_name);



        $Posts = Post::create([

            'post_name'     => $request->name_post_vw ,
            'post_title'    => $request-> post_title_view ,
            'post_about'    => !is_null($request->post_dsrpt) ? $request->post_dsrpt : "",
            'post_link'     => $request->input('link_youtube', ''),
            'download_file' => 'uploads/Downloads_File/'.$file_new_name,
            'avatar'        => 'uploads/PostImage/'.$photo_new_name ,
            'user_id'       => $request-> user_id_vw ,
            'category_id'   => $request->category_id_vw ,


        ]);



        $Posts->save();
        return  redirect('language/create');

    }



    public function edit( $id)
    {
        $category = Category::all();
        $users = User::all();
        $post = Post::find($id);

        return view('Post.Edit' , compact('post' ,'category' ,'users'));
    }


    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'name_post_vw'           =>'required',
            'post_title_view'        =>'required',
            'post_dsrpt'             =>'required' ,
            'link_youtube'           =>'required',
        ]);
        $post = Post::find($id);

        if($request->has('post_image_view')){
            $photo = $request->post_image_view ;
            $photo_new_name = time().$photo->getClientOriginalName();
            $photo->move('uploads/PostImage/',$photo_new_name);
        }
        if($request->has('download_file_vw')){
            $download_file = $request->download_file_vw ;
            $file_new_name = time().$download_file->getClientOriginalName();
            $download_file->move('uploads/Downloads_File/',$file_new_name);
        }
        $post->post_name     =   $request->name_post_vw;
        $post->post_title    =   $request->post_title_view;
        $post->post_about    =   $request->post_dsrpt;
        $post->post_link     =   $request->link_youtube;
        $post->user_id       =   $request->user_id;
        $post->category_id   =   $request->category_id;

        $post->save();
        return  redirect('posts/index');
    }

    public function destroy( $id)
    {
        $post = Post::find($id);
        $post->Delete();
        return redirect()->back();;
    }
}
