<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $categorys = Category::latest()->paginate(8);
        return view('Category.Index',compact('categorys'));
    }
    public function create()
    {

        return view("Category.Create");
    }

    public function store(Request $request)
    {

        $this->validate($request,[
            'category_name_view'=>'required'
        ]);

        $category = Category::create([
            'Category_Name' => $request->category_name_view
        ]);


        $category->save();
        return  redirect('category/index');
    }

    public function edit($id)
    {
        $category = Category::find($id);

        return view("Category.EditCategory",compact("category"));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'category_name_view'=>'required'
        ]);

        $category = Category::find($id);
        $category->Category_Name = $request->category_name_view ;


        $category->save();
        return  redirect('category/index');
    }


    public function destroy( $id)
    {
        $category = Category::find($id);
        $category->Delete();
        return redirect()->back();;
    }
}
