<?php

namespace App\Models;
use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;
    public $table = "posts";

    protected $fillable =[
        'post_name',
        'post_title',
        'post_about' ,
        'avatar',
        'post_link',
        'download_file',
        'user_id ',
        'category_id',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }



}


// {{-- @php
//     $categorys3 = [];
//     for ($i=0; $i < $categorys2->count() ; $i++) {
//         $categorys3[$i] = $categorys2[$i]->category_id;
//     }
//     $data = collect($categorys3);

//     $elements = $data->countBy();


// @endphp --}}
