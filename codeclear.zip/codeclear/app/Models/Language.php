<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    use HasFactory;

    public $table = "languages";

    protected $fillable =[
        'language_Name',
        'language_about',
        'language_code',
        'post_id' ,
    ];
}
